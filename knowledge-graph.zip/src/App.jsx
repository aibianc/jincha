import { useState, useCallback } from 'react'
import Graph from './components/Graph'
import AddNodeForm from './components/AddNodeForm'
import AddEdgeForm from './components/AddEdgeForm'
import SearchBar from './components/SearchBar'
import NodeDetail from './components/NodeDetail'
import { useGraphData } from './hooks/useGraphData'
import './App.css'

export default function App() {
  const {
    nodes, edges, graphData, loading, error,
    addNode, addEdge, deleteNode, deleteEdge, refresh,
  } = useGraphData()

  const [focusNodeId, setFocusNodeId] = useState(null)
  const [selectedNode, setSelectedNode] = useState(null)
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [activeTab, setActiveTab] = useState('add') // add, search, detail

  const handleNodeClick = useCallback((node) => {
    setFocusNodeId(node.id)
    const fullNode = nodes.find(n => n.id === node.id)
    setSelectedNode(fullNode || node)
    setActiveTab('detail')
  }, [nodes])

  const handleSearchFocus = useCallback((node) => {
    setFocusNodeId(node.id)
    const fullNode = nodes.find(n => n.id === node.id)
    setSelectedNode(fullNode || node)
    setActiveTab('detail')
  }, [nodes])

  const handleFocusNeighbor = useCallback((neighbor) => {
    setFocusNodeId(neighbor.id)
    setSelectedNode(neighbor)
    setActiveTab('detail')
  }, [])

  const handleDeleteNode = useCallback(async (id) => {
    if (!confirm('确定要删除该节点及其所有关系吗？')) return
    try {
      await deleteNode(id)
      if (focusNodeId === id) {
        setFocusNodeId(null)
        setSelectedNode(null)
      }
    } catch (err) {
      alert('删除失败: ' + err.message)
    }
  }, [deleteNode, focusNodeId])

  const handleDeleteEdge = useCallback(async (id) => {
    try {
      await deleteEdge(id)
    } catch (err) {
      alert('删除关系失败: ' + err.message)
    }
  }, [deleteEdge])

  const handleBackgroundClick = useCallback(() => {
    setFocusNodeId(null)
    setSelectedNode(null)
    setActiveTab('add')
  }, [])

  if (error) {
    return (
      <div className="app">
        <div className="error-screen">
          <h2>连接错误</h2>
          <p>{error}</p>
          <p className="error-hint">请检查 .env 文件中的 Supabase 配置是否正确</p>
          <button onClick={refresh} className="btn-primary">重试</button>
        </div>
      </div>
    )
  }

  return (
    <div className="app">
      {/* Sidebar */}
      <aside className={`sidebar ${sidebarOpen ? 'open' : 'closed'}`}>
        <div className="sidebar-header">
          <h2>知识关系网</h2>
          <button className="btn-icon sidebar-toggle" onClick={() => setSidebarOpen(!sidebarOpen)}>
            {sidebarOpen ? '‹' : '›'}
          </button>
        </div>

        <SearchBar nodes={nodes} onFocus={handleSearchFocus} />

        <div className="sidebar-tabs">
          <button
            className={`tab-btn ${activeTab === 'add' ? 'active' : ''}`}
            onClick={() => setActiveTab('add')}
          >
            添加
          </button>
          <button
            className={`tab-btn ${activeTab === 'detail' ? 'active' : ''}`}
            onClick={() => setActiveTab('detail')}
            disabled={!selectedNode}
          >
            详情
          </button>
        </div>

        <div className="sidebar-content">
          {activeTab === 'add' && (
            <>
              <AddNodeForm onAdd={addNode} />
              <AddEdgeForm nodes={nodes} onAdd={addEdge} />
              <div className="sidebar-stats">
                <span>{nodes.length} 个节点</span>
                <span>{edges.length} 条关系</span>
              </div>
            </>
          )}
          {activeTab === 'detail' && selectedNode && (
            <NodeDetail
              node={selectedNode}
              edges={edges}
              nodes={nodes}
              onFocusNeighbor={handleFocusNeighbor}
              onDeleteNode={handleDeleteNode}
              onDeleteEdge={handleDeleteEdge}
            />
          )}
        </div>
      </aside>

      {/* Mobile sidebar toggle */}
      {!sidebarOpen && (
        <button className="mobile-sidebar-toggle" onClick={() => setSidebarOpen(true)}>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M3 12h18M3 6h18M3 18h18" />
          </svg>
        </button>
      )}

      {/* Main graph area */}
      <main className="main-area" onClick={handleBackgroundClick}>
        {loading ? (
          <div className="loading-screen">
            <div className="loading-spinner" />
            <p>加载知识图谱...</p>
          </div>
        ) : graphData.nodes.length === 0 ? (
          <div className="empty-screen">
            <div className="empty-icon">🧠</div>
            <h2>开始构建你的知识网络</h2>
            <p>在左侧添加节点和关系，探索知识之间的联系</p>
          </div>
        ) : (
          <Graph
            graphData={graphData}
            focusNodeId={focusNodeId}
            onFocusNode={handleSearchFocus}
            onNodeClick={handleNodeClick}
          />
        )}
      </main>
    </div>
  )
}
