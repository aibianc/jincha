export default function NodeDetail({ node, edges, nodes, onFocusNeighbor, onDeleteNode, onDeleteEdge }) {
  if (!node) return null

  const relatedEdges = edges.filter(
    e => e.source_id === node.id || e.target_id === node.id
  )

  const getNeighbor = (edge) => {
    const neighborId = edge.source_id === node.id ? edge.target_id : edge.source_id
    return nodes.find(n => n.id === neighborId)
  }

  const getTypeColor = (type) => {
    const colors = {
      concept: '#6C5CE7', person: '#00B894', event: '#E17055',
      place: '#0984E3', idea: '#FDCB6E', skill: '#E84393',
      resource: '#00CEC9', default: '#636E72',
    }
    return colors[type] || colors.default
  }

  return (
    <div className="node-detail">
      <div className="node-detail-header">
        <span className="node-detail-dot" style={{ backgroundColor: getTypeColor(node.type) }} />
        <h3>{node.name}</h3>
        <button className="btn-icon btn-delete" onClick={() => onDeleteNode(node.id)} title="删除节点">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M3 6h18M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2m3 0v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6h14" />
          </svg>
        </button>
      </div>
      <div className="node-detail-meta">
        <span className="node-type-badge" style={{ backgroundColor: getTypeColor(node.type) + '22', color: getTypeColor(node.type), borderColor: getTypeColor(node.type) + '44' }}>
          {node.type}
        </span>
        {node.created_at && (
          <span className="node-date">{new Date(node.created_at).toLocaleDateString('zh-CN')}</span>
        )}
      </div>
      {node.note && (
        <div className="node-detail-note">
          <p>{node.note}</p>
        </div>
      )}
      {relatedEdges.length > 0 && (
        <div className="node-detail-edges">
          <h4>关系 ({relatedEdges.length})</h4>
          {relatedEdges.map(edge => {
            const neighbor = getNeighbor(edge)
            if (!neighbor) return null
            return (
              <div key={edge.id} className="edge-item">
                <div className="edge-info" onClick={() => onFocusNeighbor(neighbor)}>
                  <span className="edge-label">{edge.label || '关联'}</span>
                  <span className="edge-arrow">→</span>
                  <span className="edge-neighbor-name">{neighbor.name}</span>
                </div>
                <button className="btn-icon btn-delete-sm" onClick={() => onDeleteEdge(edge.id)} title="删除关系">
                  &times;
                </button>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
