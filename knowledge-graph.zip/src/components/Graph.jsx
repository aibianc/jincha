import { useRef, useEffect, useCallback, useState, useMemo } from 'react'
import ForceGraph2D from 'react-force-graph-2d'

const TYPE_COLORS = {
  concept: '#6C5CE7',
  person: '#00B894',
  event: '#E17055',
  place: '#0984E3',
  idea: '#FDCB6E',
  skill: '#E84393',
  resource: '#00CEC9',
  default: '#636E72',
}

function getColor(type) {
  return TYPE_COLORS[type] || TYPE_COLORS.default
}

export default function Graph({ graphData, focusNodeId, onFocusNode, onNodeClick }) {
  const fgRef = useRef()
  const containerRef = useRef(null)
  const [dimensions, setDimensions] = useState({ width: 800, height: 600 })
  const [hoveredNode, setHoveredNode] = useState(null)

  // Responsive sizing
  useEffect(() => {
    const updateSize = () => {
      if (containerRef.current) {
        setDimensions({
          width: containerRef.current.clientWidth,
          height: containerRef.current.clientHeight,
        })
      }
    }
    updateSize()
    window.addEventListener('resize', updateSize)
    return () => window.removeEventListener('resize', updateSize)
  }, [])

  // Build adjacency map for highlight
  const adjacencyMap = useMemo(() => {
    const map = new Map()
    graphData.nodes.forEach(n => map.set(n.id, new Set()))
    graphData.links.forEach(l => {
      const sId = typeof l.source === 'object' ? l.source.id : l.source
      const tId = typeof l.target === 'object' ? l.target.id : l.target
      if (map.has(sId)) map.get(sId).add(tId)
      if (map.has(tId)) map.get(tId).add(sId)
    })
    return map
  }, [graphData])

  // Focus on node with smooth animation
  useEffect(() => {
    if (!focusNodeId || !fgRef.current) return
    const fg = fgRef.current
    const targetNode = graphData.nodes.find(n => n.id === focusNodeId)
    if (!targetNode) return

    // Wait for node to have coordinates
    const tryFocus = () => {
      if (targetNode.x != null && targetNode.y != null) {
        fg.centerAt(targetNode.x, targetNode.y, 800)
        fg.zoom(2.5, 800)
      } else {
        requestAnimationFrame(tryFocus)
      }
    }
    tryFocus()
  }, [focusNodeId, graphData.nodes])

  // Warm up the simulation
  useEffect(() => {
    const fg = fgRef.current
    if (!fg) return
    fg.d3AlphaDecay(0.02)
    fg.d3VelocityDecay(0.3)
    fg.warmupTicks(50)
    fg.cooldownTicks(100)
  }, [])

  const handleNodeClick = useCallback((node) => {
    if (onNodeClick) onNodeClick(node)
  }, [onNodeClick])

  const handleNodeHover = useCallback((node) => {
    setHoveredNode(node)
  }, [])

  // Custom node canvas rendering
  const nodeCanvasObject = useCallback((node, ctx, globalScale) => {
    const isFocused = focusNodeId === node.id
    const isNeighbor = focusNodeId && adjacencyMap.get(focusNodeId)?.has(node.id)
    const isDimmed = focusNodeId && !isFocused && !isNeighbor
    const isHovered = hoveredNode?.id === node.id

    const color = getColor(node.type)
    const baseRadius = isFocused ? 10 : isHovered ? 8 : 6
    const radius = baseRadius / globalScale * (globalScale > 1.5 ? 1 : 1)

    // Glow effect for focused node
    if (isFocused) {
      const gradient = ctx.createRadialGradient(
        node.x, node.y, radius * 0.5,
        node.x, node.y, radius * 3
      )
      gradient.addColorStop(0, color + '80')
      gradient.addColorStop(1, color + '00')
      ctx.fillStyle = gradient
      ctx.beginPath()
      ctx.arc(node.x, node.y, radius * 3, 0, 2 * Math.PI)
      ctx.fill()
    }

    // Node circle
    ctx.globalAlpha = isDimmed ? 0.15 : 1
    ctx.fillStyle = color
    ctx.beginPath()
    ctx.arc(node.x, node.y, radius, 0, 2 * Math.PI)
    ctx.fill()

    // Border
    ctx.strokeStyle = isFocused ? '#fff' : isHovered ? '#ddd' : 'rgba(255,255,255,0.3)'
    ctx.lineWidth = isFocused ? 2.5 / globalScale : 1.5 / globalScale
    ctx.stroke()

    // Label
    const fontSize = Math.max(12 / globalScale, 3)
    ctx.font = `${isFocused ? 'bold ' : ''}${fontSize}px -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif`
    ctx.textAlign = 'center'
    ctx.textBaseline = 'top'

    // Text shadow for readability
    ctx.fillStyle = 'rgba(0,0,0,0.7)'
    ctx.fillText(node.name, node.x + 0.5 / globalScale, node.y + radius + 4 / globalScale + 0.5 / globalScale)
    ctx.fillStyle = isDimmed ? 'rgba(255,255,255,0.15)' : '#fff'
    ctx.fillText(node.name, node.x, node.y + radius + 4 / globalScale)

    ctx.globalAlpha = 1
  }, [focusNodeId, adjacencyMap, hoveredNode])

  // Custom link rendering (curved)
  const linkCanvasObject = useCallback((link, ctx, globalScale) => {
    const isRelated = focusNodeId && (
      (typeof link.source === 'object' ? link.source.id : link.source) === focusNodeId ||
      (typeof link.target === 'object' ? link.target.id : link.target) === focusNodeId
    )
    const isDimmed = focusNodeId && !isRelated

    ctx.globalAlpha = isDimmed ? 0.06 : 0.4
    ctx.strokeStyle = isRelated ? '#74b9ff' : '#636e72'
    ctx.lineWidth = isRelated ? 2 / globalScale : 1 / globalScale

    const sx = link.source.x
    const sy = link.source.y
    const tx = link.target.x
    const ty = link.target.y

    // Curved line
    const dx = tx - sx
    const dy = ty - sy
    const dist = Math.sqrt(dx * dx + dy * dy)
    const curvature = 0.2
    const mx = (sx + tx) / 2 - dy * curvature
    const my = (sy + ty) / 2 + dx * curvature

    ctx.beginPath()
    ctx.moveTo(sx, sy)
    ctx.quadraticCurveTo(mx, my, tx, ty)
    ctx.stroke()

    // Link label
    if (link.label && globalScale > 0.8) {
      const fontSize = Math.max(10 / globalScale, 2.5)
      ctx.font = `${fontSize}px -apple-system, BlinkMacSystemFont, sans-serif`
      ctx.textAlign = 'center'
      ctx.textBaseline = 'middle'
      ctx.globalAlpha = isDimmed ? 0.05 : 0.6
      ctx.fillStyle = '#dfe6e9'
      const lx = (sx + tx) / 2 - dy * curvature * 0.5
      const ly = (sy + ty) / 2 + dx * curvature * 0.5
      ctx.fillText(link.label, lx, ly)
    }

    ctx.globalAlpha = 1
  }, [focusNodeId])

  return (
    <div ref={containerRef} className="graph-container">
      <ForceGraph2D
        ref={fgRef}
        graphData={graphData}
        width={dimensions.width}
        height={dimensions.height}
        nodeCanvasObject={nodeCanvasObject}
        nodePointerAreaPaint={(node, color, ctx) => {
          ctx.beginPath()
          ctx.arc(node.x, node.y, 8, 0, 2 * Math.PI)
          ctx.fillStyle = color
          ctx.fill()
        }}
        onNodeClick={handleNodeClick}
        onNodeHover={handleNodeHover}
        linkCanvasObject={linkCanvasObject}
        linkDirectionalArrowLength={0}
        linkDirectionalArrowRelPos={0}
        d3Force={{
          charge: { strength: -300 },
          link: { distance: 150 },
        }}
        cooldownTicks={200}
        onEngineStop={() => fgRef.current && fgRef.current.zoomToFit(400, 80)}
      />
    </div>
  )
}
