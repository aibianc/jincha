import { useState } from 'react'

const NODE_TYPES = ['concept', 'person', 'event', 'place', 'idea', 'skill', 'resource']

export default function AddNodeForm({ onAdd }) {
  const [name, setName] = useState('')
  const [type, setType] = useState('concept')
  const [note, setNote] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState(null)

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!name.trim()) return
    setSubmitting(true)
    setError(null)
    try {
      await onAdd({ name: name.trim(), type, note: note.trim() })
      setName('')
      setNote('')
      setType('concept')
    } catch (err) {
      setError(err.message || '添加失败')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <form className="sidebar-form" onSubmit={handleSubmit}>
      <h3>添加节点</h3>
      <div className="form-group">
        <label>名称 *</label>
        <input
          type="text"
          value={name}
          onChange={e => setName(e.target.value)}
          placeholder="输入节点名称"
          required
        />
      </div>
      <div className="form-group">
        <label>类型</label>
        <select value={type} onChange={e => setType(e.target.value)}>
          {NODE_TYPES.map(t => (
            <option key={t} value={t}>{t}</option>
          ))}
        </select>
      </div>
      <div className="form-group">
        <label>备注</label>
        <textarea
          value={note}
          onChange={e => setNote(e.target.value)}
          placeholder="可选备注信息"
          rows={3}
        />
      </div>
      {error && <div className="form-error">{error}</div>}
      <button type="submit" disabled={submitting || !name.trim()} className="btn-primary">
        {submitting ? '添加中...' : '添加节点'}
      </button>
    </form>
  )
}
