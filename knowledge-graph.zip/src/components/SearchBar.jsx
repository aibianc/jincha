import { useState, useRef, useEffect } from 'react'

export default function SearchBar({ nodes, onFocus }) {
  const [query, setQuery] = useState('')
  const [showResults, setShowResults] = useState(false)
  const inputRef = useRef(null)
  const containerRef = useRef(null)

  const filtered = query.trim()
    ? nodes.filter(n =>
        n.name.toLowerCase().includes(query.toLowerCase()) ||
        n.type.toLowerCase().includes(query.toLowerCase())
      ).slice(0, 10)
    : []

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setShowResults(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const handleSelect = (node) => {
    onFocus(node)
    setQuery('')
    setShowResults(false)
  }

  return (
    <div className="search-bar" ref={containerRef}>
      <div className="search-input-wrapper">
        <svg className="search-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <circle cx="11" cy="11" r="8" />
          <path d="m21 21-4.35-4.35" />
        </svg>
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={e => { setQuery(e.target.value); setShowResults(true) }}
          onFocus={() => setShowResults(true)}
          placeholder="搜索节点..."
          className="search-input"
        />
        {query && (
          <button className="search-clear" onClick={() => { setQuery(''); setShowResults(false) }}>
            &times;
          </button>
        )}
      </div>
      {showResults && filtered.length > 0 && (
        <div className="search-results">
          {filtered.map(node => (
            <div key={node.id} className="search-result-item" onClick={() => handleSelect(node)}>
              <span className="search-result-dot" style={{ backgroundColor: getTypeColor(node.type) }} />
              <span className="search-result-name">{node.name}</span>
              <span className="search-result-type">{node.type}</span>
            </div>
          ))}
        </div>
      )}
      {showResults && query.trim() && filtered.length === 0 && (
        <div className="search-results">
          <div className="search-result-empty">未找到匹配节点</div>
        </div>
      )}
    </div>
  )
}

function getTypeColor(type) {
  const colors = {
    concept: '#6C5CE7', person: '#00B894', event: '#E17055',
    place: '#0984E3', idea: '#FDCB6E', skill: '#E84393',
    resource: '#00CEC9', default: '#636E72',
  }
  return colors[type] || colors.default
}
