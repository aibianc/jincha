import { useState, useEffect } from 'react'

export default function AddEdgeForm({ nodes, onAdd }) {
  const [sourceId, setSourceId] = useState('')
  const [targetId, setTargetId] = useState('')
  const [label, setLabel] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState(null)

  useEffect(() => {
    setError(null)
  }, [sourceId, targetId])

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!sourceId || !targetId) return
    if (sourceId === targetId) {
      setError('不能连接到自身')
      return
    }
    setSubmitting(true)
    setError(null)
    try {
      await onAdd({ source_id: sourceId, target_id: targetId, label: label.trim() })
      setLabel('')
    } catch (err) {
      setError(err.message || '添加关系失败')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <form className="sidebar-form" onSubmit={handleSubmit}>
      <h3>添加关系</h3>
      <div className="form-group">
        <label>起始节点 *</label>
        <select value={sourceId} onChange={e => setSourceId(e.target.value)} required>
          <option value="">选择节点</option>
          {nodes.map(n => (
            <option key={n.id} value={n.id}>{n.name} ({n.type})</option>
          ))}
        </select>
      </div>
      <div className="form-group">
        <label>目标节点 *</label>
        <select value={targetId} onChange={e => setTargetId(e.target.value)} required>
          <option value="">选择节点</option>
          {nodes.filter(n => n.id !== sourceId).map(n => (
            <option key={n.id} value={n.id}>{n.name} ({n.type})</option>
          ))}
        </select>
      </div>
      <div className="form-group">
        <label>关系类型</label>
        <input
          type="text"
          value={label}
          onChange={e => setLabel(e.target.value)}
          placeholder="如：属于、相关、引用"
        />
      </div>
      {error && <div className="form-error">{error}</div>}
      <button type="submit" disabled={submitting || !sourceId || !targetId} className="btn-primary">
        {submitting ? '添加中...' : '添加关系'}
      </button>
    </form>
  )
}
