import { useState, useEffect, useCallback } from 'react'
import { supabase } from '../lib/supabase'

export function useGraphData() {
  const [nodes, setNodes] = useState([])
  const [edges, setEdges] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const fetchData = useCallback(async () => {
    try {
      setLoading(true)
      const [nodesRes, edgesRes] = await Promise.all([
        supabase.from('nodes').select('*').order('created_at', { ascending: false }),
        supabase.from('edges').select('*').order('created_at', { ascending: false }),
      ])
      if (nodesRes.error) throw nodesRes.error
      if (edgesRes.error) throw edgesRes.error
      setNodes(nodesRes.data || [])
      setEdges(edgesRes.data || [])
      setError(null)
    } catch (err) {
      console.error('Failed to fetch data:', err)
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchData()
  }, [fetchData])

  const addNode = async ({ name, type, note }) => {
    const { data, error } = await supabase
      .from('nodes')
      .insert([{ name, type: type || 'concept', note: note || '' }])
      .select()
      .single()
    if (error) throw error
    setNodes(prev => [data, ...prev])
    return data
  }

  const addEdge = async ({ source_id, target_id, label }) => {
    const { data, error } = await supabase
      .from('edges')
      .insert([{ source_id, target_id, label: label || '' }])
      .select()
      .single()
    if (error) throw error
    setEdges(prev => [data, ...prev])
    return data
  }

  const deleteNode = async (id) => {
    const { error } = await supabase.from('nodes').delete().eq('id', id)
    if (error) throw error
    setNodes(prev => prev.filter(n => n.id !== id))
    setEdges(prev => prev.filter(e => e.source_id !== id && e.target_id !== id))
  }

  const deleteEdge = async (id) => {
    const { error } = await supabase.from('edges').delete().eq('id', id)
    if (error) throw error
    setEdges(prev => prev.filter(e => e.id !== id))
  }

  const graphData = {
    nodes: nodes.map(n => ({ id: n.id, name: n.name, type: n.type, note: n.note })),
    links: edges.map(e => ({
      id: e.id,
      source: e.source_id,
      target: e.target_id,
      label: e.label,
    })),
  }

  return {
    nodes,
    edges,
    graphData,
    loading,
    error,
    addNode,
    addEdge,
    deleteNode,
    deleteEdge,
    refresh: fetchData,
  }
}
