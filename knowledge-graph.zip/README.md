# 个人知识关系网

一个基于力导向图的个人知识管理工具，用于可视化和探索知识节点之间的关系。

## 技术栈

- **React 18** - 前端框架
- **Vite** - 构建工具
- **react-force-graph-2d** - 力导向图可视化
- **Supabase** - 后端数据库
- **GitHub Pages** - 静态部署

## 功能特性

- 添加知识节点（名称、类型、备注）
- 创建节点之间的关系
- 力导向布局，节点自然散开
- 曲线连线，美观清晰
- 点击节点聚焦：移到中心并放大，相关节点高亮，无关节点变淡
- 点击相邻节点切换焦点，平滑过渡动画
- 搜索节点并快速聚焦
- 响应式设计，支持移动端

## 快速开始

### 1. 安装依赖

```bash
npm install
```

### 2. 配置 Supabase

1. 在 [Supabase](https://supabase.com) 创建项目
2. 在 SQL Editor 中执行 `schema.sql` 创建数据表
3. 复制 `.env.example` 为 `.env` 并填入你的 Supabase 凭证：

```env
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANKEY=your-anon-key
```

### 3. 本地开发

```bash
npm run dev
```

访问 http://localhost:5173

### 4. 构建

```bash
npm run build
```

## 部署到 GitHub Pages

### 方法一：使用 GitHub Actions（推荐）

1. 在仓库中创建 `.github/workflows/deploy.yml`：

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [main]

permissions:
  contents: read
  pages: write
  id-token: write

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: npm

      - run: npm ci
      - run: npm run build

      - uses: actions/upload-pages-artifact@v3
        with:
          path: dist

      - uses: actions/deploy-pages@v4
```

2. 在仓库 Settings > Pages 中，Source 选择 "GitHub Actions"
3. 在仓库 Settings > Secrets and variables > Actions 中添加：
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANKEY`

4. 推送代码到 main 分支即可自动部署

### 方法二：手动部署

```bash
npm run build
```

将 `dist` 目录的内容推送到仓库的 `gh-pages` 分支：

```bash
git subtree push --prefix dist origin gh-pages
```

或在 `dist` 目录执行：

```bash
cd dist
git init
git add -A
git commit -m "deploy"
git remote add origin <your-repo-url>
git push -f origin main:gh-pages
```

## 数据模型

### nodes 表

| 字段 | 类型 | 说明 |
|------|------|------|
| id | uuid | 主键 |
| name | text | 节点名称 |
| type | text | 节点类型（concept/person/event/place/idea/skill/resource） |
| note | text | 备注信息 |
| created_at | timestamp | 创建时间 |

### edges 表

| 字段 | 类型 | 说明 |
|------|------|------|
| id | uuid | 主键 |
| source_id | uuid | 起始节点 ID |
| target_id | uuid | 目标节点 ID |
| label | text | 关系类型标签 |
| created_at | timestamp | 创建时间 |

## 项目结构

```
├── package.json
├── vite.config.js
├── index.html
├── schema.sql
├── .env.example
├── README.md
└── src/
    ├── main.jsx
    ├── App.jsx
    ├── App.css
    ├── lib/
    │   └── supabase.js
    ├── hooks/
    │   └── useGraphData.js
    └── components/
        ├── Graph.jsx
        ├── AddNodeForm.jsx
        ├── AddEdgeForm.jsx
        ├── SearchBar.jsx
        └── NodeDetail.jsx
```

## 许可证

MIT
