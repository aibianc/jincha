-- Supabase 建表 SQL
-- 在 Supabase 控制台的 SQL Editor 中执行

-- 启用 UUID 扩展
create extension if not exists "uuid-ossp";

-- 节点表
create table nodes (
  id uuid default uuid_generate_v4() primary key,
  name text not null,
  type text not null default 'concept',
  note text default '',
  created_at timestamp with time zone default timezone('utc', now())
);

-- 关系表
create table edges (
  id uuid default uuid_generate_v4() primary key,
  source_id uuid references nodes(id) on delete cascade not null,
  target_id uuid references nodes(id) on delete cascade not null,
  label text default '',
  created_at timestamp with time zone default timezone('utc', now())
);

-- 索引
create index idx_edges_source on edges(source_id);
create index idx_edges_target on edges(target_id);
create index idx_nodes_type on nodes(type);

-- 行级安全策略 (RLS)
alter table nodes enable row level security;
alter table edges enable row level security;

-- 公开只读策略（可根据需要修改）
create policy "公开只读 nodes" on nodes for select using (true);
create policy "公开插入 nodes" on nodes for insert with check (true);
create policy "公开更新 nodes" on nodes for update using (true);
create policy "公开删除 nodes" on nodes for delete using (true);

create policy "公开只读 edges" on edges for select using (true);
create policy "公开插入 edges" on edges for insert with check (true);
create policy "公开更新 edges" on edges for update using (true);
create policy "公开删除 edges" on edges for delete using (true);
